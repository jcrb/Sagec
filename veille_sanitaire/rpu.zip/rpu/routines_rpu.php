<?php
/**
*	routines_rpu.php
*/
$backPathToRoot = "../../";
require($backPathToRoot."dbConnection.php");
require($backPathToRoot."date.php");

function sexe()
{
	global $connexion;
	$requete = "SELECT sexe, COUNT(sexe) AS sumsexe FROM rpu GROUP BY sexe ORDER BY sexe";
	$resultat = ExecRequete($requete,$connexion);
	while($rep=mysql_fetch_array($resultat))
	{
		print($rep[sexe]."  ".$rep[sumsexe]."<br>");
	}
}

function commune()
{
	global $connexion;
	$requete = "SELECT ville, COUNT(ville) AS sumsexe FROM rpu GROUP BY ville ORDER BY ville";
	$resultat = ExecRequete($requete,$connexion);
	while($rep=mysql_fetch_array($resultat))
	{
		print($rep[ville]."  ".$rep[sumsexe]."<br>");
	}
}

function passages()
{
	global $connexion;
	$requete = "SELECT date_jour, COUNT(date_jour) AS sumsexe FROM rpu GROUP BY date_jour ORDER BY date_jour";
	$resultat = ExecRequete($requete,$connexion);
	while($rep=mysql_fetch_array($resultat))
	{
		print($rep[date_jour]."  ".$rep[sumsexe]."<br>");
	}
}

sexe();
commune();
passages();